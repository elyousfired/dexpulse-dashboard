# Identity

Name: Setup
Role: Creates branch and establishes build/test baseline
