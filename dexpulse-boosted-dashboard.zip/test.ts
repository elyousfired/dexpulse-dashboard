import { parseNumberShorthand } from './utils'; console.log(parseNumberShorthand('2.5k'));  
