console.log(require('./utils').parseNumberShorthand('2.5k'))  
